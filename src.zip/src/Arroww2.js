import React from 'react'

// function Arroww2() {
//   return (
//     <div>
//     <h1>Learning Never end</h1>
      
//     </div>
//   );
// }
// let Arroww2 = () =>  <h2>VICKY RAI</h2>;

// const Arroww2 = (props) => {
//   return(
//     <>  
//     <h1>Hello REACT  I'am {props.name}</h1>
//     <h1>My Age {props.age}</h1>
//     </>
//   );
// }

let Arroww2 = props =>  <h2>{props.name}</h2>;
export default Arroww2;
