import React from 'react';
import ReactDOM from 'react-dom';




 class Vlog extends React.Component {
  render() {
    return (
      <div>
        <h1 className='co'>Blog</h1>
      </div>
    )
  }
}
 
export default Vlog;