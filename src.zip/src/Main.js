import React from 'react';
import axios from 'axios';

class Main extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            id: '',
            name: '',
            email: '',
            data: [],
            userdetails: [],
            result: [],
        }
        this.addFormData = this.addFormData.bind(this);
    }

    addFormData() {
        let formdata = new FormData();
        formdata.append('name', this.state.name);
        formdata.append('email', this.state.email);

        axios.post('http://localhost/react/Data.php', formdata)
        .then(response => {
            axios.post('http://localhost/react/Data.php').then(response => {
                this.setState({ data: response.data });
            });
            alert("Record Inserted");
        })

    }



    render() {
        return (

            <div>
                <center>
                    <h1><b>ADD STUDENT DATA</b></h1>

                    <form>
                        <input type="hidden" id="Username"
                            placeholder="id" ref="myUsername" defaultValue={this.state.userdetails.id} />

                        <input type="text" id="Username"
                            placeholder="Enter Username" ref="myUsername" defaultValue={this.state.userdetails.name}
                            onChange={event => this.setState({ name: event.target.value })} />

                        <input type="email" id="Email" placeholder="Enter email" ref="myEmail" defaultValue={this.state.userdetails.email} onChange={event => this.setState({ email: event.target.value })} />
                        <button type="submit" onClick={this.addFormData}>Add</button>
                    </form>

                </center>
            </div>
        )
    };
}
export default Main;