 import React from 'react'


class Student extends React.Component{
    constructor(props){
        super(props);
         this.state={
          header:"" 
         
         }
    
       
    }
    render(){
     let  a = this.state.header;
     let reverse=[];
     while(a>0){
        reverse.push(a);
         a--;
         console.log(a)
     }
         return(

            <div>

                Enter Value1<input type="text"  onChange={e=>this.setState({header:e.target.value})} />
                <div>
                    <h1>{reverse}</h1>
                   
                </div>

            </div>
         )
    }
}
   export default Student;