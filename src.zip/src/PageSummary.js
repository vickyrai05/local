import React from 'react';
import ReactDOM from 'react-dom';



 class Pagesummary extends React.Component {
  render() {
    return (
    
      <div className='ab'>
        <h2>Category-1</h2>
        
      </div>
    )
  }
}
 
export default Pagesummary;

