import React, { Component } from 'react';

class Todolisto extends Component {
  constructor(props) {
    super(props);

    // Initialize state to store the todo items
    this.state = {
      todos: [],
      newTodoText: '',
    };
  }

  componentDidMount() {
    // Load data from local storage when the component mounts
    const storedTodos = localStorage.getItem('todos');
    if (storedTodos) {
      this.setState({ todos: JSON.parse(storedTodos) });
    }
  }

  componentDidUpdate() {
    // Save data to local storage whenever the todos state changes
    localStorage.setItem('todos', JSON.stringify(this.state.todos));
  }

  handleInputChange = (event) => {
    this.setState({ newTodoText: event.target.value });
  };

  handleAddTodo = () => {
    if (this.state.newTodoText.trim() === '') return;

    const newTodo = {
      id: Date.now(),
      text: this.state.newTodoText,
      completed: false,
    };

    this.setState((prevState) => ({
      todos: [...prevState.todos, newTodo],
      newTodoText: '',
    }));
  };

  // handleToggleTodo = (id) => {
  //   this.setState((prevState) => ({
  //     todos: prevState.todos.map((todo) =>
  //       todo.id === id ? { ...todo, completed: !todo.completed } : todo
  //     ),
  //   }));
  // };

  handleDeleteTodo = (id) => {
    this.setState((prevState) => ({
      todos: prevState.todos.filter((todo) => todo.id !== id),
    }));
  };

  render() {
    return (
      <div>
        <input
          type="text"
          value={this.state.newTodoText}
          onChange={this.handleInputChange}
        />
        <button onClick={this.handleAddTodo}>Add Todo</button>

        <ul>
          {this.state.todos.map((todo) => (
            <li key={todo.id}>
              <span

                onClick={() => this.handleToggleTodo(todo.id)}
              >
                {todo.text}
              </span>
              <button onClick={() => this.handleDeleteTodo(todo.id)}>Delete</button>
            </li>
          ))}
        </ul>
      </div>
    );
  }
}

export default Todolisto;