import React from 'react';
import ReactDOM from 'react-dom';



 class Home extends React.Component {
  render() {
    return (
      <div className="">
       
      </div>
    )
  }
}
 
export default Home;

