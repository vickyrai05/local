 import React, { Component } from 'react';


  class Propwithclass3 extends Component {
   render() {
     return (
       <div>
         <h1>My Name is  {this.props.name}</h1>
         {this.props.children}
       </div>
     )
   }
 }
   
 
 
 
 export default Propwithclass3;