import React from "react";
import ReactDOM from "react-dom";

class AddPage extends React.Component {
  render() {
    return (
      <div>
        <div>
        <h2 className="ab">Category-2</h2>
        </div>
        <div>
        <h2 className="ab">Category-2</h2>
        </div>
      </div>
    );
  }
}

export default AddPage;
