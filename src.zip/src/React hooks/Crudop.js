import React from 'react';
import { useState } from 'react';
import axios from 'axios';

function Crudop() {
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')


  const changeName = ((e) => {
    setName(e.target.value);

  })


  const changeEmail = ((e) => {
    setEmail(e.target.value);
  })
  const handleSubmit = (e) => {
    e.preventDefault();
 axios.post('http://localhost:3002/users',{
   e_name:name,
   e_email:email,
 });
  }
  return (
    <div align='center'>
    <form onSubmit={handleSubmit}>
        <label>Enter Your Name :</label>
        <input type='text' placeholder='Enter Your Name'name='name' value={name} onChange={changeName} />
        <br></br>
        <br></br>
        <label>Enter Your Email: </label>
        <input type='Email' placeholder='Enter Your Email'name='email' value={email} onChange={changeEmail} />
        <br></br>
        <br></br>
        <button >Submit</button>
      </form>

    </div>
  )
}

export default Crudop
