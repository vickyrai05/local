import React from 'react';
import ReactDOM from 'react-dom';



 class About extends React.Component {
  render() {
    return (
      <div>
        <h1 className='co'>About</h1>
      </div>
    )
  }
}
 
export default About;

