import React from 'react';
import ReactDOM from 'react-dom';




 class Pages extends React.Component {
  render() {
    return (
      <div>
      <h1 className='co'>Pages</h1>
      </div>
    )
  }
}
 
export default Pages;